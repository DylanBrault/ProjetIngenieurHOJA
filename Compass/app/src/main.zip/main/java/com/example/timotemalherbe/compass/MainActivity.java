package com.example.timotemalherbe.compass;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.TextView;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.File;
import java.io.IOException;
import android.os.Handler;
import android.os.Environment;
import android.util.Log;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private float currentDegree = 0f;

    // device sensor manager
    private SensorManager mSensorManager;

    TextView tvHeading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvHeading = (TextView) findViewById(R.id.textView);

        // initialize your android device sensor capabilities
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // Get the directory for the user's public pictures directory.
        final File path =
                Environment.getExternalStoragePublicDirectory
                        (
                                //Environment.DIRECTORY_PICTURES
                                Environment.DIRECTORY_DCIM + "/root/"
                        );

        // Make sure the path directory exists.
        if(!path.exists())
        {
            // Make it, if it doesn't exist
            path.mkdirs();
        }

        final File file = new File(path,"mesuh.txt");//My Files/Internal storage/Documents

        try {

            file.createNewFile();
            FileOutputStream fOut = new FileOutputStream(file);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.append("hhhhhhhhhh \\n hhhhh");
            BufferedWriter b = new BufferedWriter(myOutWriter);
            b.newLine();
            myOutWriter.append("hhhhhhhhhh \\n hhhhh");
            b.close();
            myOutWriter.close();

            fOut.flush();
            fOut.close();

            Log.d("Exception", "-------------------File ok: " + path  );
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());

        }




        final Handler h = new Handler();
        h.postDelayed(new Runnable()
        {

            @Override
            public void run()
            {
               /* try {

                    //file.createNewFile();
                    //FileOutputStream fOut = new FileOutputStream(file);
                    //OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
                    //myOutWriter.append(tvHeading.getText());

                    //myOutWriter.close();

                    //fOut.flush();
                    //fOut.close();
                }
                catch (IOException e) {
                    Log.e("Exception", "File write failed: " + e.toString());

                }*/

                h.postDelayed(this, 1000);
            }
        }, 1000);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // for the system's orientation sensor registered listeners
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_GAME);
    }

    protected void onPause() {
        super.onPause();

        // to stop the listener and save battery
        mSensorManager.unregisterListener(this);
    }


    public void onSensorChanged(SensorEvent event) {

        // get the angle around the z-axis rotated
        final float degree = Math.round(event.values[0]);

        tvHeading.setText(Float.toString(degree));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // not in use
    }

}
